#ifndef SEMAFORO_H
#define SEMAFORO_H

void salvarEstado(const char* arquivo, const char* estado);

#endif