#include <iostream>
#include <windows.h>
#include "semaforo.h"

using namespace std;

int main()
{
    cout << "CORE iniciado..." << endl;

    while (true)
    {
        // ESTADO 1
        salvarEstado("DADOS/veiculo1.txt", "VERDE");
        salvarEstado("DADOS/veiculo2.txt", "VERMELHO");
        salvarEstado("DADOS/pedestre1.txt", "VERMELHO");
        salvarEstado("DADOS/pedestre2.txt", "VERDE");

        cout << "Estado 1 - Horizontal Liberado" << endl;
        Sleep(5000);

        // ESTADO 2
        salvarEstado("DADOS/veiculo1.txt", "AMARELO");
        salvarEstado("DADOS/veiculo2.txt", "VERMELHO");
        salvarEstado("DADOS/pedestre1.txt", "VERMELHO");
        salvarEstado("DADOS/pedestre2.txt", "VERMELHO");

        cout << "Estado 2 - Transicao" << endl;
        Sleep(2000);

        // ESTADO 3
        salvarEstado("DADOS/veiculo1.txt", "VERMELHO");
        salvarEstado("DADOS/veiculo2.txt", "VERDE");
        salvarEstado("DADOS/pedestre1.txt", "VERDE");
        salvarEstado("DADOS/pedestre2.txt", "VERMELHO");

        cout << "Estado 3 - Vertical Liberado" << endl;
        Sleep(5000);

        // ESTADO 4
        salvarEstado("DADOS/veiculo1.txt", "VERMELHO");
        salvarEstado("DADOS/veiculo2.txt", "AMARELO");
        salvarEstado("DADOS/pedestre1.txt", "VERMELHO");
        salvarEstado("DADOS/pedestre2.txt", "VERMELHO");

        cout << "Estado 4 - Transicao" << endl;
        Sleep(2000);
    }

    return 0;
}