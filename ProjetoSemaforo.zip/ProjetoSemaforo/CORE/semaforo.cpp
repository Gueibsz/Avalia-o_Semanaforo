#include <cstdio>
#include <iostream>
#include "semaforo.h"

using namespace std;

void salvarEstado(const char *arquivo, const char *estado)
{
    FILE *f = fopen(arquivo, "w");

    if (f == NULL)
    {
        cout << "ERRO AO CRIAR: " << arquivo << endl;
        return;
    }

    fprintf(f, "%s", estado);
    fclose(f);

    cout << "Gravou: " << arquivo << " = " << estado << endl;
}