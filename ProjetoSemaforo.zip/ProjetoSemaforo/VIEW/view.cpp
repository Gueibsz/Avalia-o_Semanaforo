#include <iostream>
#include <fstream>
#include <string>
#include <windows.h>

using namespace std;

string lerEstado(const char *arquivo)
{
    ifstream file(arquivo);

    if (!file.is_open())
        return "ERRO";

    string estado;
    getline(file, estado);

    return estado;
}

void desenhaSemaforoVeiculo(string estado)
{
    cout << "+-------+\n";

    if (estado == "VERMELHO")
        cout << "| \033[31m00\033[0m    |\n";
    else
        cout << "| 00    |\n";

    if (estado == "AMARELO")
        cout << "| \033[33m00\033[0m    |\n";
    else
        cout << "| 00    |\n";

    if (estado == "VERDE")
        cout << "| \033[32m00\033[0m    |\n";
    else
        cout << "| 00    |\n";

    cout << "+-------+\n";
}

void desenhaSemaforoPedestre(string estado)
{
    cout << "+-------+\n";

    if (estado == "VERMELHO")
        cout << "| \033[31m00\033[0m    |\n";
    else
        cout << "|       |\n";

    if (estado == "VERDE")
        cout << "| \033[32m00\033[0m    |\n";
    else
        cout << "|       |\n";

    cout << "+-------+\n";
}

int main()
{
    system("cls");

    cout << "=====================================================\n";
    cout << "           SISTEMA DE CONTROLE DE TRAFEGO\n";
    cout << "=====================================================\n\n";

    cout << "                     S4\n";
    cout << "                     ^\n";
    cout << "                     |\n";
    cout << "                     |\n";
    cout << "                     |\n";
    cout << "                     |\n";
    cout << "                     |\n\n";

    cout << "S1 -----------------+-----------------> S3\n\n";

    cout << "                     |\n";
    cout << "                     |\n";
    cout << "                     |\n";
    cout << "                     |\n";
    cout << "                     ^\n";
    cout << "                     S2\n\n";

    cout << "Fluxo Horizontal : S1 -> S3\n";
    cout << "Fluxo Vertical   : S4 -> S2\n\n";

    cout << "Carregando simulacao...\n";

    Sleep(7000);

    while (true)
    {
        string v1 = lerEstado("DADOS/veiculo1.txt");
        string v2 = lerEstado("DADOS/veiculo2.txt");
        string p1 = lerEstado("DADOS/pedestre1.txt");
        string p2 = lerEstado("DADOS/pedestre2.txt");

        system("cls");

        cout << "=====================================================\n";
        cout << "           SISTEMA DE CONTROLE DE TRAFEGO\n";
        cout << "=====================================================\n\n";

        cout << "SEMAFORO S1 -> S3\n";
        desenhaSemaforoVeiculo(v1);

        cout << "\n";

        cout << "SEMAFORO S4 -> S2\n";
        desenhaSemaforoVeiculo(v2);

        cout << "\n";

        cout << "PEDESTRE 1\n";
        desenhaSemaforoPedestre(p1);

        cout << "\n";

        cout << "PEDESTRE 2\n";
        desenhaSemaforoPedestre(p2);

        cout << "\n=====================================================\n";

        cout << "S1 -> S3 : " << v1 << endl;
        cout << "S4 -> S2 : " << v2 << endl;

        cout << "Pedestre 1 : " << p1 << endl;
        cout << "Pedestre 2 : " << p2 << endl;

        Sleep(500);
    }

    return 0;
}